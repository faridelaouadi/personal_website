from flask import Flask, render_template, request
import os
from werkzeug.utils import secure_filename


app = Flask(__name__)

@app.route("/", methods=["GET","POST"])
def home():
    return render_template("base.html", message='')

@app.route('/upload', methods=["GET","POST"])
def upload():
    message = 'im '
    uploaded_files = request.files.getlist("file")
    total_images = len(uploaded_files)
    modified_files = []
    for file in uploaded_files:
        filename = secure_filename(file.filename)
        filepath = os.path.join('./static/', f"uploads/{filename}")
        file.save(filepath)
        modified_files.append([filename,filepath])
    return render_template("base.html", message=message, modified_files=modified_files)


    #find server space 