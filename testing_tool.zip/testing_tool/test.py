def lengthOfLongestSubstring(string):
    position_of_seen_characters = {}
    seen_characters = []
    characters_to_remove = []
    length_of_longest_subsequence = 0
    running_total = 0
    substring = []
    for i in range(len(string)):
        

        if string[i] in seen_characters:
            if running_total > length_of_longest_subsequence:
                length_of_longest_subsequence = running_total 
            last_seen = position_of_seen_characters[string[i]]
            
            running_total = i - last_seen


            for j in range(len(seen_characters)):
                print("Removing characters")
                if position_of_seen_characters[seen_characters[j]] <= last_seen:
                    print(f"Last seen {string[i]} ----> {last_seen}")
                    print(f"Letter to remove {seen_characters[j]} as it was last seen ----> {position_of_seen_characters[seen_characters[j]]}")
                    characters_to_remove.append(seen_characters[j])
                    substring.remove(seen_characters[j])
            print(f"now the seen chars looks like : {seen_characters}\n")
            print(f"Characters to remove {characters_to_remove}")
            seen_characters = [character for character in seen_characters if character not in characters_to_remove]
            
            substring.append(string[i])
            position_of_seen_characters[string[i]] = i
            seen_characters.append(string[i])
        else:
            substring.append(string[i])
            position_of_seen_characters[string[i]] = i
            running_total = running_total + 1
            seen_characters.append(string[i])
        
        print(f"Current char : {string[i]}")
        print(f"Seen characters : {seen_characters}")
        print(f"String : {string}")
        print(f"Running total : {running_total}")
        print(f"Position of seen characters : {position_of_seen_characters}")
        print(f"Substring {substring}\n\n\n")
        
            
    print(substring)
    if running_total > length_of_longest_subsequence:
        return running_total
    else:
        return len(substring)
    
print(lengthOfLongestSubstring("abcabcbb"))